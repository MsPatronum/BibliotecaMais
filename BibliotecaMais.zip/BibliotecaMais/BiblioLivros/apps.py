from django.apps import AppConfig


class BibliolivrosConfig(AppConfig):
    name = 'BiblioLivros'
